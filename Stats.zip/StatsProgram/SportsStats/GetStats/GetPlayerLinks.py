from SportsStats.Parsers.Urls import *
from SportsStats.FileSystem import file_system_utils as fs


class GetPlayerLinks:
    def __init__(self, base_url, mode=None):
        self.base_url = base_url  # Normal URL of the website
        self.session = Session()
        self.urls = GetUrls(self.base_url)
        self.page_indices = self.urls.get_page_indices()

        if mode == "pro":
            self.mode = mode
        else:
            self.mode = "all"

    def get_all_player_links(self):
        fs.init_dirs()
        for url in self.page_indices:
            page_contents = self.session.soup_request(url)
            players_div = soupify(page_contents.find("div", {"id": DIV_PLAYERS}))
            if self.mode == "pro":
                players = players_div.find_all("p", class_="nhl")
            else:
                players = players_div.find_all("p")

            current_char = get_last_url_char(url)
            current_link_file = f"{LINKS_DIR}/{current_char}.txt"
            fs.del_file_content(current_link_file)
            print(f"Working on {current_char}")

            for player in players:
                player_name = player.text
                player_link = join_urls(self.base_url, player.a["href"])
                fs.smart_write(current_link_file, f"{player_name}, {player_link}\n")
