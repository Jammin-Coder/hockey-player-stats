HTML_PARSER = "lxml"


# DIRECTORY PATHS
PLAYER_DIR = "players"
LINKS_DIR = f"{PLAYER_DIR}/links"
DATA_DIR = f"{PLAYER_DIR}/data"



# URL PATHS
PLAYERS_PATH = "/players/"

# Content IDs
PAGE_INDEX = "page_index"
DIV_PLAYERS = "div_players"
ALL_PLAYERS = "all_players"
