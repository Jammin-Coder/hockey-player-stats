from SportsStats.WebActions.web_actions import *
from SportsStats.settings import *
from .parser_utils import *


class GetUrls:
    def __init__(self, base_url):
        self.base_url = base_url  # Normal URL of the website
        self.players_url = join_urls(self.base_url, "/players/")
        self.session = Session()
        self.players_page = soupify(self.session.get(self.players_url))

    def get_page_indices(self) -> list:
        """
        Returns a list of URLs for all of the player groups.
        ["{self.base_url}/players/a", "{self.base_url}/players/b", "{self.base_url}/players/c",
            "{self.base_url}/players/etc.."]
        :return:
        """
        page_index = self.players_page.find("ul", class_=PAGE_INDEX)
        page_index = soupify(page_index)
        li_tags = page_index.find_all("li")  # Gets the list that contain the <a> tags and page links

        # TODO: Make these 2 comprehensions neater
        # All of the <a> tags containing the links to player pages
        a_tags = soupify([li.a for li in li_tags]).find_all("a")
        player_page_links = [join_urls(self.base_url, (a["href"])) for a in a_tags]  # Gets the links from a_tags
        return player_page_links
