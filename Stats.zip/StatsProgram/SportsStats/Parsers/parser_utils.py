def xor(condition1, condition2) -> bool:
    if condition1 and condition2:
        return False
    if condition1 or condition2:
        return True


def join_urls(url1, url2) -> str:
    """
    Joins 2 paths (specifically URLs) together neatly.
    If url1 is "https://test.com/"
    and url2 is "/admin/login/", the method will return
    "https://test.com/admin/login/". and won't give you double
    forward slashes like it would if you were just
    combining the 2 paths: https://test.com//admin/login

    :param url1:
    :param url2:
    :return:
    """

    if xor(url1[-1] == "/", url2[0] == "/"):
        # If one but not both of the urls have a "/"
        # return the URLs combined.
        return url1 + url2
    elif url1[-1] != "/" and url2[0] != "/":
        # If neither of the URLs have a "/", add one between them.
        return f"{url1}/{url2}"
    else:
        # Both URLs have a "/", remove the "/" from the first
        # URL and return the URLs combined
        return url1[:-1] + url2


def stringify(lst, separator=None) -> str:
    out_str = ""
    for item in lst:
        if lst.index(item) == len(lst) - 1:
            out_str += str(item)
        else:
            out_str += str(item) + separator
    return out_str


def get_last_url_char(url):
    for i in range(1, len(url)):
        char = url[-i]
        if char != "/":
            return char
