import requests
from .Soup import *


class Session:
    def __init__(self):
        self.session = requests.Session()

    def get(self, url):
        response = self.session.get(url)
        return response.content

    def soup_request(self, url):
        return soupify(self.get(url))
