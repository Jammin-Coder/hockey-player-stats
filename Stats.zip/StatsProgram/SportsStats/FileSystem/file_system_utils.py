import os
from SportsStats import settings


def try_make_dir(name):
    try:
        os.mkdir(name)
    except OSError:
        print(f"Directory '{name}' already exists")


def init_dirs():
    try_make_dir(settings.PLAYER_DIR)
    try_make_dir(settings.LINKS_DIR)
    try_make_dir(settings.DATA_DIR)


def smart_write(path, content):
    with open(path, "a") as f:
        f.write(content)


def write(path, content):
    with open(path, "w") as f:
        f.write(content)


def del_file_content(path):
    write(path, "")


def read(path):
    with open(path, "r") as f:
        return f.read()
