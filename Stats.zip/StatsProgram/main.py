from SportsStats.GetStats.GetPlayerLinks import *

hockey_urls = GetPlayerLinks("https://www.hockey-reference.com/")
hockey_urls.get_all_player_links()

# football_urls = GetPlayers("https://www.pro-football-reference.com/")
# football_urls.get_all_players()

